const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');

btn.addEventListener('click',function(){
    let string = document.querySelector('input').value.toLowerCase().split(" ");

    wyswietl.innerHTML = `Twoje imię to: ${string[0]}, a nazwisko: ${string[1]}`
})