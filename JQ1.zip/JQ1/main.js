$(document).ready(function() {
    alert('Witaj na mojej stronie!');
});