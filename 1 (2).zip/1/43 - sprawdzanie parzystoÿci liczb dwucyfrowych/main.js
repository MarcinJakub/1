let liczba = document.querySelector('#liczba');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function () {

    let l = parseInt(liczba.value);
    if (l >= 10 && l < 100) {
        if (l % 2 === 0) {
            wyswietl.innerHTML = `Liczba dwucyfrowa parzysta`
        } else {
            wyswietl.innerHTML = `Liczba dwucyfrowa nieparzysta`
        }
    } else if (l < 10 && l > 0 || l > 99) {
        wyswietl.innerHTML = `Liczba nie jest dwucyfrowa`
    } else {
        wyswietl.innerHTML = `Liczba nie jest dodatnia`
    }
})