let n = document.querySelector('#n');
let min = document.querySelector('#min');
let max = document.querySelector('#max');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function () {
    wyswietl.innerHTML = `Wylosowane liczby: <br>`;

    if(parseInt(min.value) < parseInt(max.value)) {
        for (let i = 0; i < n.value; i++) {
            let l = Math.floor(Math.random() * (parseInt(max.value) - parseInt(min.value) + 1) + parseInt(min.value));
            wyswietl.innerHTML += `${l} `;

        }
    } else{
        wyswietl.innerHTML = `Błąd! Min musi być mniejsze niż max!`
    }
})