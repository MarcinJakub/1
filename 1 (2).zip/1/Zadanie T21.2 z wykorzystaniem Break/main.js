let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let a = parseInt(document.querySelector('#a').value);
    wyswietl.innerHTML = "";
    if(a <= 30 && a >= 1){
        for(let i = 1; i <= 30; i++){
            wyswietl.innerHTML += `${i} `
            if(i === a){
                break;
            }
        }
    }
    else{
        for(let i = 1; i <= 30; i++){
            wyswietl.innerHTML += `${i} `
        }
    }
})