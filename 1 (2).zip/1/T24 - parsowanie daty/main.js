const date = new Date("27 march 2021");

console.log(date);

const promotionEndsAt = new Date(PROMOTION.endsAt);

const date2 = new Date(2000, 0, 12, 15, 10, 5, 500);

console.log(date2);
date2.setFullYear(2001);
console.log(date2);