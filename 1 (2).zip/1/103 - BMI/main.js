const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');

function obliczBMI(waga, wzrost){
    return waga / Math.pow(wzrost/100, 2);;
}
function poziom(bmi){
    switch(true){
        case (bmi < 16):
            return `<b>Wygłodzenie</b>`;
            break;
        case (bmi >= 16 && bmi < 17):
            return `<b>Wychudzenie</b>`;
            break;
        case (bmi >= 17 && bmi < 18,5):
            return `<b>Niedowaga</b>`;
            break;
        case (bmi >= 18,5 && bmi < 25):
            return `<b>Optimum</b>`
            break;
        case (bmi >= 25 && bmi < 30):
            return `<b>Nadwaga</b>`;
            break;
        case (bmi >= 30 && bmi < 35):
            return `<b>Otyłość I st./<b>`
            break;
        case (bmi >= 35 && bmi < 40):
            return `<b>Otyłość II st.</b>`
            break;
        case (bmi >= 40):
            return `<b>Otyłość III st.</b>`
            break;

    }
}


btn.addEventListener('click', function(){
    const waga = parseFloat(document.querySelector('#waga').value);
    const wzrost = parseFloat(document.querySelector('#wzrost').value);

    wyswietl.innerHTML = `BMI dla podanej wagi i wzrostu wynosi ${obliczBMI(waga, wzrost)}.<br><br> ${poziom(obliczBMI(waga,wzrost))}`;
})