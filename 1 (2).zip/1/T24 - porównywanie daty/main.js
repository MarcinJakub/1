const date1 = new Date("22 March 2015");
const date2 = new Date("10 September 2010");
const date3 = new Date("10 September 2010");

console.log(date1 < date2);

console.log(date2.getTime() === date3.getTime());

const birthdate = new Date(USER.birthdate);
const today = new Date();

if(today.getMonth() === birthdate.getMonth() && today.getDate() === birthdate.getDate()) {
    console.log("Dzisiaj urodziny!");
}

const btn = document.querySelector('button');

btn.addEventListener('click', function(){
    const wyswietl = document.querySelector('#wyswietl');

    let imie1 = document.querySelector('#imie1').value;
    let urodziny1 = new Date(document.querySelector('#urodziny1').value);

    let imie2 = document.querySelector('#imie2').value;
    let urodziny2 = new Date(document.querySelector('#urodziny2').value);

    if(urodziny1.getTime() < urodziny2.getTime()){
        wyswietl.innerHTML = `${imie1} jest starszy niż ${imie2}.`
    } else if(urodziny1.getTime() > urodziny2.getTime()){
        wyswietl.innerHTML = `${imie2} jest starszy niż ${imie1}.`
    } else{
        wyswietl.innerHTML = `${imie1} urodził się w tym samym dniu co ${imie2}.`
    }



})

