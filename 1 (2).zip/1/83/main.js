let A = document.querySelector('#a');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function () {
    let a = parseInt(A.value)
    wyswietl.innerHTML = ``;
    for (let i = 0; i < a; i++) {
        for(let j = 0; j < a; j++){
            if( i === j){
                wyswietl.innerHTML += "<b>1</b>";
            }
            else{
                wyswietl.innerHTML += "0";
            }
        }
        wyswietl.innerHTML += "<br>";
    }
})