const btn = document.querySelector('button');
let wyswietl = document.querySelector('#wyswietl');

function obliczDzielnik(a, b){
    while(a != b){
        if(a > b){
            a -= b;
        }
        else{
            b -= a;
        }
    }

    wyswietl.innerHTML = `Dzielnik obu tych liczb wynosi ${a}`;
}

btn.addEventListener('click', function (){
    let a = parseInt(document.querySelector('#a').value);
    let b = parseInt(document.querySelector('#b').value);

    obliczDzielnik(a, b);
})