
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

function miesiac(month){
    switch(month){
        case 1: wyswietl.innerHTML += `styczeń`
            break;
        case 2: wyswietl.innerHTML += `luty`
            break;
        case 3: wyswietl.innerHTML += `marzec`
            break;
        case 4: wyswietl.innerHTML += `kwiecień`
            break;
        case 5: wyswietl.innerHTML += `maj`
            break;
        case 6: wyswietl.innerHTML += `czerwiec`
            break;
        case 7: wyswietl.innerHTML += `lipiec`
            break;
        case 8: wyswietl.innerHTML += `sierpień`
            break;
        case 9: wyswietl.innerHTML += `wrzesień`
            break;
        case 10: wyswietl.innerHTML += `październik`
            break;
        case 11: wyswietl.innerHTML += `listopad`
            break;
        case 12: wyswietl.innerHTML += `grudzień`
            break;
        default: wyswietl.innerHTML += `BŁĄD! Należy podać liczbę od 1 do 12`
            break;
        }
}

btn.addEventListener('click', function(){
    let month = parseInt(document.querySelector('#month').value);
    wyswietl.innerHTML = `${month} miesiąc to: `
    miesiac(month);



})