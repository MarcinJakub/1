let liczba1 = parseInt(prompt("Wprowadź pierwszą liczbę"));
let liczba2 = parseInt(prompt("Wprowadź drugą liczbę"));

liczba1 = Number(liczba1);
liczba2 = Number(liczba2);


let suma = liczba1 + liczba2;
document.write("Suma: " + liczba1 + " + " + liczba2 + " = " + suma + "<br>");

let roznica = liczba1 - liczba2;
document.write("Różnica: " + liczba1 + "-" + liczba2 + "=" + roznica + "<br>");

let iloczyn = liczba1 * liczba2;
document.write("Iloczyn: " + liczba1 + "*" + liczba2 + "=" + iloczyn + "<br>");


if (liczba2 === 0) {
    // akcja gdy prawda
    let iloraz1 = "Nie dzielimy przez zero! ";
    //wyswietlanie wynikow
    document.write(iloraz1);
} else ;
{
    //akcja gdy fałsz
    let iloraz = liczba1 / liczba2;
    document.write("Iloraz: " + liczba1 + "/" + liczba2 + "=" + iloczyn + "<br>");
}
    