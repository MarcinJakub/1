let dzien = document.querySelector('#dzien');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let d = parseInt(dzien.value);

    switch(d){
        case 1:
            wyswietl.innerHTML = `Poniedzialek`
            break;
        case 2:
            wyswietl.innerHTML = `Wtorek`
            break;
        case 3:
            wyswietl.innerHTML = `Środa`
            break;
        case 4:
            wyswietl.innerHTML = `Czwartek`
            break;
        case 5:
            wyswietl.innerHTML = `Piątek`
            break;
        case 6:
            wyswietl.innerHTML = `Sobota`
            break;
        case 7:
            wyswietl.innerHTML = `Niedziela`
            break;
        default:
            wyswietl.innerHTML = `Błąd! Należy podać liczbę od 1 do 7.`
    }
})