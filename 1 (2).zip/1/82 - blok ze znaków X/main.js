let znaki = document.querySelector('#znaki');
let wiersze = document.querySelector('#wiersze');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let a = parseInt(znaki.value);
    let b = parseInt(wiersze.value);
    wyswietl.innerHTML = ""

    for(let i = 0; i < b; i++){
        for(let j = 0; j < a; j++){
            wyswietl.innerHTML += `X`
        }
        wyswietl.innerHTML += `<br>`
    }
})