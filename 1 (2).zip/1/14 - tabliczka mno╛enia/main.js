let liczba = document.querySelector('#liczba');
const wynik = document.querySelector('#wynik');
const btn = document.querySelector('button');

btn.addEventListener('click', function () {
    let podana = parseInt(liczba.value);
    wynik.innerHTML = `x = ${podana} <br><br>`
    for(let i = 0; i < 11; i++){
        wynik.innerHTML += `${podana} * ${i} = ${podana*i} <br>`
    }
})