alert("Witaj na mojej stronie. Miło cię widzieć!");

//to jest jakiś tekst

let imie = prompt("Jak masz na imię?","Anonim");
document.write("Cześć" + imię)
console.log("Cześć "+ imie);