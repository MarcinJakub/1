let rok = document.querySelector('#rok');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function () {
    let r = parseInt(rok.value);
    if (r % 4 == 0) {
        if (r % 100 != 0) {
            wyswietl.innerHTML = `Rok ${r} jest przystępny`
        } else if (r % 400 == 0) {
            wyswietl.innerHTML = `Rok ${r} jest przystepny`
        } else {
            wyswietl.innerHTML = `Rok ${r} nie jest przystępny`
        }
    } else {
        wyswietl.innerHTML = `Rok ${r} nie jest przystępny`
    }
})