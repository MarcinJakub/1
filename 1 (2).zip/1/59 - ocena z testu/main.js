let procent = document.querySelector('#procent');
let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function (){
    let p = parseInt(procent.value);
    let punkty = Math.floor(p/10);
    let ocena;

    switch(punkty){
        case 10:
            wyswietl.innerHTML = `Ocena wynosi 5`
            ocena = 5;
            break;
        case 9:
            wyswietl.innerHTML = `Ocena wynosi 5`
            break;
            ocena = 5;
        case 8:
            wyswietl.innerHTML = `Ocena wynosi 4,5`
            break;
            ocena = 4.5;
        case 7:
            wyswietl.innerHTML = `Ocena wynosi 4`
            ocena = 4;
            break;
        case 6:
            wyswietl.innerHTML = `Ocena wynosi 3,5`
            ocena = 3.5;
            break;
        case 5:
            wyswietl.innerHTML = `Ocena wynosi 3`
            ocena = 3;
            break;
        default:
            wyswietl.innerHTML = `Ocena wynosi 2`
            ocena = 2;
            break;
    }
})