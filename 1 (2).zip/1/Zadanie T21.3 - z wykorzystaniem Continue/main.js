let wyswietl = document.querySelector('#wyswietl');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let a = parseInt(document.querySelector('#a').value);
    wyswietl.innerHTML = ``;

    if(a <= 15 && a >= 1){
        for(let i = 0; i < 15; i++){
            if(i+1 === a){
                wyswietl.innerHTML += `{-} `
                continue;
            }
            wyswietl.innerHTML += `${i+1} `
        }
    }
    else{
        for(let i = 0; i < 15; i++){
            wyswietl.innerHTML += `${i+1} `
        }
    }


})