let wyswietl1 = document.querySelector('#wyswietl1');
let wyswietl2 = document.querySelector('#wyswietl2');
let btn1 = document.querySelector('#btn1');
let btn2 = document.querySelector('#btn2');

function wartosc_bezwzgledna_1(x) {
    if (x > 0) {
        return x;
    } else{
        return -x;
    }

}

function wartosc_bezwzgledna_2(x) {
    let wynik = x > 0 ? x : -x;
    return wynik;
}

btn1.addEventListener('click', function () {
    let x = parseInt(document.querySelector('#x').value);

    let wynik1 = wartosc_bezwzgledna_1(x);


    wyswietl1.innerHTML = `Wartość bezwzględna podanej liczby to: ${wynik1}`;

})

btn2.addEventListener('click', function (){
    let x = parseInt(document.querySelector('#x').value);

    let wynik2 = wartosc_bezwzgledna_2(x);

    wyswietl2.innerHTML = `Wartość bezwzględna podanej liczby to: ${wynik2}`;
})



