function setup(){
    createCanvas(1200,800);
}

function draw(){

}