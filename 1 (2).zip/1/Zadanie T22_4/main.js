const btn = document.querySelector('button');
let wyswietl = document.querySelector('#wyswietl');

function wypisz(a, b){
    if(a < b){
        wyswietl.innerHTML = `<span id="lower">${a}</span> < <span id="higher">${b}</span>`
    }
    else if(a > b){
        wyswietl.innerHTML = `<span id="higher">${a}</span> > <span id="lower">${b}</span>`
    }
    else {
        wyswietl.innerHTML = `<span id="same">${a}</span> = <span id="same">${b}</span>`
    }
}

btn.addEventListener('click', function (){
    let a = parseInt(document.querySelector('#a').value);
    let b = parseInt(document.querySelector('#b').value);
    wypisz(a,b);

})