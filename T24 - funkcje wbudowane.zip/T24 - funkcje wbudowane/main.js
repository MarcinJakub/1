const wyswietl1 = document.querySelector('#wyswietl1');
let wyswietl_godzine = document.querySelector('#wyswietl_godzine');

const d = new Date();
let day = d.getDate();
let month = d.getMonth() + 1;
let year = d.getFullYear();
let weekday = d.getDay();

day = (day < 10) ? "0"+day : day;
month = (month < 10) ? "0"+month : month;

wyswietl1.innerHTML = `<h2>Dzisiaj jest: </h2><br>`+day+`.`+month+`.`+year+`, `+dayoftheweek(weekday)+`<br>`;

function dayoftheweek(weekday){
    switch(weekday){
        case 0:
            return "niedziela";
        case 1:
            return "poniedziałek";
        case 2:
            return "wtorek";
        case 3:
            return "środa";
        case 4:
            return "czwartek";
        case 5:
            return "piątek";
        case 6:
            return "sobota";
    }
}

let time = new Date();

let hour = time.getHours();
let minute = time.getMinutes();
let second = time.getSeconds();

hour = (hour < 10) ? "0"+hour : hour;
minute = (minute < 10) ? "0"+minute : minute;
second = (second < 10) ? "0"+second : second;

wyswietl_godzine.innerHTML = `${hour}:${minute}:${second}`

window.onload = setInterval(clock,1000);

function clock(){
    let time = new Date();

    let hour = time.getHours();
    let minute = time.getMinutes();
    let second = time.getSeconds();

    hour = (hour < 10) ? "0"+hour : hour;
    minute = (minute < 10) ? "0"+minute : minute;
    second = (second < 10) ? "0"+second : second;

    wyswietl_godzine.innerHTML = `${hour}:${minute}:${second}`
}



//============================================================================================================

const wyswietl2 = document.querySelector('#wyswietl2');
const btn1 = document.querySelector('#btn1');

btn1.addEventListener('click', function(){
    let dzien = document.querySelector('#dzien').value;
    let miesiac = document.querySelector('#miesiac').value;
    const dateOne = new Date(new Date().getFullYear(), miesiac - 1, dzien);
    let dateTwo = new Date();


    const diffInDays = Math.round((dateOne.getTime() - dateTwo.getTime())/(24*60*60*1000) + 1);

    let daysLeft;
    if(diffInDays <= 0){
        daysLeft = 365 + diffInDays;
    } else{
        daysLeft = diffInDays;
    }


    wyswietl2.innerHTML = `Do twoich następnych urodzin pozostało: ${daysLeft} dni!`
})

//============================================================================================================

const wyswietl3 = document.querySelector('#wyswietl3');
const btn2 = document.querySelector('#btn2');

btn2.addEventListener('click', function(){
    const d_current = new Date();
    const d_newYear = new Date(new Date().getFullYear(), 11, 31);
    const time = Math.abs(d_current - d_newYear);
    const numberOfDays = Math.ceil(time/(1000 * 60 * 60 * 24));

    wyswietl3.innerHTML = `Nowy rok zacznie się za: <h1>${numberOfDays} dni!<h1></h1><br> Będzie to rok: <b>${new Date().getFullYear()+1}</b>`
})

//============================================================================================================

const wyswietl4 = document.querySelector('#wyswietl4');
const btn3 = document.querySelector('#btn3');


btn3.addEventListener('click', function(){
    const dateOfBirth = new Date(document.querySelector('#dateOfBirth').value);
    const d_current = new Date(new Date().getFullYear(),  new Date().getMonth(), new Date().getDate());
    const time = Math.abs(dateOfBirth - d_current);
    const days = Math.ceil(time/(1000 * 60 * 60 * 24));


    const timesMercuryOrbited = Math.floor(days/87.969);
    const timesWenusOrbited = Math.floor(days/224.7);
    const timesMarsOrbited = Math.floor(days/687);
    const timesJupiterOrbited = Math.floor(days/4332.5);

    wyswietl4.innerHTML = `Żyjesz od <b>${days} dni</b>, co oznacza, że:<br><br>`

    let razy = (timesJupiterOrbited == 1) ? "raz." : "razy.";

    wyswietl4.innerHTML += `Za twojego życia Merkury wykonał <b>${timesMercuryOrbited}</b> obiegów orbitalnych wokół Słońca.<br>
                           Wenus takich obiegów wykonał <b>${timesWenusOrbited}</b>.<br>
                           W przypadku Marsa jest to <b>${timesMarsOrbited}</b> okrążeń,<br>
                           a Jowisz okrążył Słońce tylko <b>${timesJupiterOrbited}</b> ${razy}`;
})

//============================================================================================================

const btn4 = document.querySelector('#btn4');
const wyswietl5 = document.querySelector('#wyswietl5');

btn4.addEventListener('click', function(){
    const odjazd = new Date(new Date().getFullYear(),  new Date().getMonth(), new Date().getDate(), document.querySelector('#hour').value, document.querySelector('#minute').value);

    const hh = odjazd.getHours() + 1;
    const mm = odjazd.getMinutes() + 46;

    let przyjazd = new Date(new Date().getFullYear(),  new Date().getMonth(), new Date().getDate(), hh, mm);

    let hour = przyjazd.getHours();
    let minute = przyjazd.getMinutes();
    minute = (minute < 10) ? "0"+minute : minute;

    wyswietl5.innerHTML = `Przy założeniu, że średni czas przejazdu z Głogowa do Wrocławia wynosi <b>godzinę i 46 minut</b>,<br>
                           to pociąg licząc od podanej godziny dotrze do Wrocławia o godzinie <b>${hour}:${minute}</b>.`
})