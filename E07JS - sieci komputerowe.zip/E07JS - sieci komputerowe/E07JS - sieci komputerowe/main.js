let ilosc1 = document.getElementById('ilosc1');
let ilosc2 = document.getElementById('ilosc2');
let ilosc3 = document.getElementById('ilosc3');
let ilosc4 = document.getElementById('ilosc4');

const update1 = document.getElementById('update1');
const update2 = document.getElementById('update2');
const update3 = document.getElementById('update3');
const update4 = document.getElementById('update4');

const order1 = document.getElementById('order1');
const order2 = document.getElementById('order2');
const order3 = document.getElementById('order3');
const order4 = document.getElementById('order4');

function braki(){
    if(ilosc1.innerHTML === "0"){
        ilosc1.style.backgroundColor = "red";
    } else if(Number(ilosc1.innerHTML) >= 1 && Number(ilosc1.innerHTML) <= 5){
        ilosc1.style.backgroundColor = "yellow"
    } else{
        ilosc1.style.backgroundColor = "honeydew"
    }

    if(ilosc2.innerHTML === "0"){
        ilosc2.style.backgroundColor = "red";
    } else if(Number(ilosc2.innerHTML) >= 1 && Number(ilosc2.innerHTML) <= 5){
        ilosc2.style.backgroundColor = "yellow"
    } else{
        ilosc2.style.backgroundColor = "honeydew"
    }

    if(ilosc3.innerHTML === "0"){
        ilosc3.style.backgroundColor = "red";
    } else if(Number(ilosc3.innerHTML) >= 1 && Number(ilosc3.innerHTML) <= 5){
        ilosc3.style.backgroundColor = "yellow"
    } else{
        ilosc3.style.backgroundColor = "honeydew"
    }

    if(ilosc4.innerHTML === "0"){
        ilosc4.style.backgroundColor = "red";
    } else if(Number(ilosc4.innerHTML) >= 1 && Number(ilosc4.innerHTML) <= 5){
        ilosc4.style.backgroundColor = "yellow"
    } else{
        ilosc4.style.backgroundColor = "honeydew"
    }
}

function aktualizuj(){
    update1.addEventListener('click',function(){
        ilosc1.innerHTML = prompt("Podaj nową ilość: ");
        braki();
    })

    update2.addEventListener('click',function(){
        ilosc2.innerHTML = prompt("Podaj nową ilość: ");
        braki();
    })

    update3.addEventListener('click',function(){
        ilosc3.innerHTML = prompt("Podaj nową ilość: ");
        braki();
    })

    update4.addEventListener('click',function(){
        ilosc4.innerHTML = prompt("Podaj nową ilość: ");
        braki();
    })
}

function zamow(id_zamowienia, nazwa_produktu){
    alert("Zamówienie nr: " + id_zamowienia + " " + "Produkt: " + nazwa_produktu)
}

ilosc1.innerHTML = "0";
braki();

if(true){
    aktualizuj();
}

if(true){
    let id_zamowienia ={
        id_zamowienia1: 0,
        id_zamowienia2: 0,
        id_zamowienia3: 0,
        id_zamowienia4: 0
    }

    const produkty ={
        Skretka_UUTP_drut: "Skrętka U/UTP drut",
        Skretka_UUTP_linka: "Skrętka U/UTP linka",
        Wtyki: "Wtyki 8P8C",
        Moduly: "Moduły Keystone"
    }

    order1.addEventListener('click',function(){
        zamow(id_zamowienia.id_zamowienia1, produkty.Skretka_UUTP_drut)
        id_zamowienia.id_zamowienia1++
    })

    order2.addEventListener('click',function(){
        zamow(id_zamowienia.id_zamowienia2, produkty.Skretka_UUTP_linka)
        id_zamowienia.id_zamowienia2++
    })

    order3.addEventListener('click',function(){
        zamow(id_zamowienia.id_zamowienia3, produkty.Wtyki)
        id_zamowienia.id_zamowienia3++
    })

    order4.addEventListener('click',function(){
        zamow(id_zamowienia.id_zamowienia4, produkty.Moduly)
        id_zamowienia.id_zamowienia4++
    })
}



