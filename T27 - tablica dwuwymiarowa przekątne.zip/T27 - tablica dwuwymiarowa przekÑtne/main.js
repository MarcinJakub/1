const tablica = [3][3];
const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');

function losujLiczby(tab){
    const min = 0;
    const max = 9;
    for(let row = 0; row < 3; row++){
        for(let col = 0; col < 3; col++){
            tab[row][col] = Math.random() * (max - min + 1) + min;
        }
    }
    return tab;
}

function wyswietlTablice(tab){
    for(let row = 0; row < 3; row++){
        for(let col = 0; col < 3; col++){
            wyswietl.innerHTML = `${tab[row][col]} `;
        }
        wyswietl.innerHTML = `\n`;
    }
}

function obliczSume(tab){
    let suma_lgpd = 0;
    let suma_ldpg = 0;
    for(let row = 0; row < 3; row++){
        for(let col = 0; col < 3; col++){
            if(row == col){
                suma_lgpd += tab[row][col]
            }
            if()
        }
    }
}

btn.addEventListener('click',function(){
    losujLiczby(tablica);
    wyswietlTablice(tablica);
})
