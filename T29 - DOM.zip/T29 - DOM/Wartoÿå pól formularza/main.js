const form = document.querySelector("#myForm");
const btn = document.querySelector("#button");
const dc = document.createDocumentFragment();
const wynik = document.querySelector('#wynik');

btn.addEventListener('click',function(){
    event.preventDefault();

    const imie = form.firstName.value;
    const nazwisko = form.lastName.value;
    const przedmiot = form.subject.value;
    const wiadomosc = form.message.value;
    const checkbox = form.remember.checked;

    const paragraph = document.createElement("p");

    paragraph.append(document.createTextNode(`${imie}\n`));
    paragraph.append(document.createTextNode(`${nazwisko}\n`));
    paragraph.append(document.createTextNode(`${przedmiot}\n`));
    paragraph.append(document.createTextNode(`${wiadomosc}\n`));
    paragraph.append(document.createTextNode(`${checkbox}\n`));
    dc.append(paragraph);
    wynik.append(dc);



})


/*
console.log(form.firstName.value);

form.lastName.value = "Kowalski";

form.message.value = "Treść";

console.log(form.subject.value);

form.subject.value = "zgloszenie";

console.log(form.remember.checked);

form.remember.checked = true; */