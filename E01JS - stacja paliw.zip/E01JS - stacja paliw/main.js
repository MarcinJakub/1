const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');

btn.addEventListener('click', function(){
    const rodzaj = (document.querySelector('#rodzaj').value).toString();
    const litry = parseFloat(document.querySelector('#litry').value);

    let koszt = 0;

    if(rodzaj == '1'){
        koszt = 4 * litry;
    } else if(rodzaj == '2'){
        koszt = 3.5 * litry;
    }

    wyswietl.innerHTML = `koszt paliwa: ${koszt} zł`


})