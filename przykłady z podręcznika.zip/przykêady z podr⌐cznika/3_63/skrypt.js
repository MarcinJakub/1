//3.63
Tablica=new Array('Anna','Adam','Piotr');
document.write(Tablica.join()+"<br>");
Tablica.reverse()
document.write(Tablica.join()+"<br>");