// Przykład 3.80
window.location.href = "http://www.helion.pl"
window.location = "https://www.google.pl/search?q=warszawa+lotnisko"