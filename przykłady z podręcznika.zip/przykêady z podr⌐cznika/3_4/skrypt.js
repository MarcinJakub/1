//Przykład 3.4
document.write("<a href='spis.html'>Spis treści</a>");