//Przykład 3.3
document.write("<h1>JavaScript</h1>");