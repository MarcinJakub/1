//Przykład 3.13
var k = true;