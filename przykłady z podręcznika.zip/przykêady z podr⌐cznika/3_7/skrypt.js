//Przykład 3.7

var a, b, c; // deklaracja zmiennych
a = 4; b = 9; // przypisanie wartości
c = a + b; // wyrażeni