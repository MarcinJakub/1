// Przykład 3.85
document.addEventListener("DOMContentLoaded", function(){console.log("DOM został wczytany");
});