//Przykład 3.39
isNaN(NaN);
isNaN(567);
isNaN(37.2);
isNaN(parseInt("zx23"));