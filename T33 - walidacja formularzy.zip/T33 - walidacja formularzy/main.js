const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');
const form = document.querySelector('form');

function sprawdz(form){
    if(form.username.value == '' || form.email.value == '' || form.password.value == '' || form.password2.value == ''){
        wyswietl.innerHTML += `Wszystkie pola muszą być wypełnione!`;
    } else{
        if(document.querySelector('#email').value.match(/zspglogow.pl$/)){
            if(form.password.value.length >= 8 && form.password.value.match(/[0-9]/) && form.password.value.match(/[a-z]/) && form.password.value.match(/[A-Z]/) && form.password.value.match(/[!@#$%^&()_+]/)){
                if(form.password2.value != form.password.value){
                    wyswietl.innerHTML += `Hasło musi być przepisane.<br>`;
                } else{
                    wyswietl.innerHTML += `Wszystkie pola wypełnione prawidłowo, potwierdzono zmianę hasła:<br><Br>`;
                    wyswietl.innerHTML += `Nazwa użytkownika: ${document.querySelector('#username').value}<br>`;
                    wyswietl.innerHTML += `E-mail: ${document.querySelector('#email').value}<br>`;
                    wyswietl.innerHTML += `Hasło: ${document.querySelector('#password').value}`
                }
            } else{
                wyswietl.innerHTML += `Hasło musi mieć co najmniej 8 znaków, duże i małe litery, cyfry oraz znaki specjalne.`;
            }
        } else{
            wyswietl.innerHTML += `E-mail musi mieć domenę zspglogow.pl`
        }
    }
}

btn.addEventListener('click', function(){
    wyswietl.innerHTML = "";
    event.preventDefault();
    sprawdz(form);
})