const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');
const form = document.querySelector('form');

function sprawdz(form){
    if(form.username.value = ''){
        return false;
    } else{
        wyswietl.innerHTML += form.username.value;
    }

    if(form.email.value = '' && form.email.value != zspglogow.pl$)

    if(document.querySelector('#password').value.length < 8){
        form.password.focus();
        return false;

    } else{

    }


    if(document.querySelector('#confirm_p').value != (document.querySelector('#password').value)){
        return false;
    } else{
        wyswietl.innerHTML += `Potwierdzono hasło`
    }
    return true;
}

btn.addEventListener('click', function(){
    wyswietl.innerHTML = '';
    sprawdz(form);

})