const div = document.querySelector('div');
const wyswietl = document.querySelector('#wyswietl');

div.addEventListener('mouseenter', function(){
    let data = new Date();
    
})