const div = document.querySelector('div');
const wyswietl = document.querySelector('#wyswietl');
let i = 0;

div.addEventListener('mouseenter', function(){
    let data = new Date();

    if(i == 0){
        wyswietl.innerHTML = `${data}`;
        i += 1;
    }
    else {
        wyswietl.innerHTML = `Data już była ;)`;
        i = 1;
    }

})

div.addEventListener('mouseleave', function(){

    wyswietl.innerHTML = "";
})