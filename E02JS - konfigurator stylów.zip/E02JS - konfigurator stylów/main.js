const blue = document.querySelector('#blue');
const steelblue = document.querySelector('#steelblue');
const olive = document.querySelector('#olive');
const section = document.querySelector('section');
const img = document.querySelector('img');
const rozmiar = document.querySelector('#rozmiar');
const ramka = document.querySelector('#ramka');

const dysk = document.querySelector('#dysk');
const kwadrat = document.querySelector('#kwadrat');
const okrag = document.querySelector('#okrag');

let kolorCzcionki = document.querySelector('select');


blue.addEventListener('click', function(){

    section.style.backgroundColor = `blue`
})

steelblue.addEventListener('click', function(){
    section.style.backgroundColor = `steelblue`
})

olive.addEventListener('click', function(){
    section.style.backgroundColor = `olive`
})

kolorCzcionki.addEventListener('change', function(){
    section.style.color = kolorCzcionki.value;
})

rozmiar.addEventListener('change', function(){
    section.style.fontSize = rozmiar.value;
})

ramka.addEventListener('change', function(){
    if(ramka.checked == false){
        img.style.border = `0px`
    } else{
        img.style.border = `1px solid white`
    }
})

dysk.addEventListener('change',function (){
    section.style.listStyleType = `disc`
})

kwadrat.addEventListener('change',function (){
    section.style.listStyleType = `square`
})

okrag.addEventListener('change',function (){
    section.style.listStyleType = `circle`
})


