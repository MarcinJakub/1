const blue = document.querySelector('#blue')
const steelblue = document.querySelector('#steelblue')
const olive = document.querySelector('#olive')