const btn = document.querySelector('button');
const wyswietl = document.querySelector('#wyswietl');

const min = 10;
const max = 99;

let tablica = [];

function generujTablice(tab){
    let tab2 = [];
    for(let i = 10; i <= 99; i++){
        tab2[i] = i;
    }

    for(let row = 0; row < 7; row++){
        tab[row] = [];
        for(let col = 0; col < 7; col++){
            let random = Math.floor(Math.random() * ((max - min + 1) + min))


            tab[row][col] = random;
            tab2[random] = 'x'
        }
    }
}

function wyswietlTablice(tab){
    for(let row = 0; row < 7; row++){
        for(let col = 0; col < 7; col++){
            wyswietl.innerHTML += `${tab[row][col]} `
        }
        wyswietl.innerHTML += `<br>`
    }
}

btn.addEventListener('click',function (){
    wyswietl.innerHTML = '';
    generujTablice(tablica);
    wyswietlTablice(tablica);
})