const btn = document.querySelector('button');


btn.addEventListener('click', function(){
    const wielkosc = document.querySelector('#n');
    const szachownica =  document.querySelector('#chessboard');

    for(let i = 0; i < wielkosc; i++){
        for(let j = 0; j < wielkosc; j++){
            var kafelek = document.cre

        }
    }

})